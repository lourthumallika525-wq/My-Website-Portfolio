---
name: Synthesized Intelligence
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45474c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#006591'
  on-secondary: '#ffffff'
  secondary-container: '#39b8fd'
  on-secondary-container: '#004666'
  tertiary: '#201100'
  on-tertiary: '#ffffff'
  tertiary-container: '#3c2300'
  on-tertiary-container: '#c88000'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display:
    fontFamily: Outfit
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Outfit
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  metric:
    fontFamily: Outfit
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  container-max: 1280px
---

## Brand & Style

This design system targets an audience of educational stakeholders, institutional leaders, and technology partners. The brand personality is **Analytical, Educational, Innovative, and Trustworthy**, prioritizing clarity and data density without sacrificing elegance.

The visual style is **Corporate / Modern** with a **Dashboard-inspired** aesthetic. It utilizes structured grid alignments, scannable information hierarchies, and subtle interactive states to convey a sense of technical precision. The UI evokes an "intelligence-first" emotional response, appearing stable and institutional yet forward-leaning through the use of vibrant accents.

## Colors

The palette is anchored by **Deep Slate Blue (#1E293B)** for core structural elements and high-level branding, ensuring a professional foundation. **Soft Cyan (#0EA5E9)** serves as the primary action color, used for buttons, links, and progress indicators to signal interactivity and innovation.

**Warm Gold (#F59E0B)** is reserved strictly for high-impact data points, metrics, and achievements, creating a clear visual distinction for "success" metrics. The background utilizes **Neutral Light Gray (#F8FAFC)** to reduce eye strain, while **Dark Charcoal (#0F172A)** provides maximum contrast for long-form reading. Use subtle slate borders to define container boundaries in lieu of heavy shadows.

## Typography

The system uses a dual-font strategy to balance character with utility. **Outfit** is used for headings and metrics; its geometric construction conveys a modern, tech-forward feeling. **Inter** is the workhorse for all body copy, UI labels, and data tables, chosen for its exceptional legibility and neutral tone.

For data-heavy views, use `label-caps` for table headers and category tags. For impact areas like case studies or portfolio highlights, use the `metric` style in the secondary or tertiary color to draw immediate attention to quantifiable results.

## Layout & Spacing

This design system employs a **Fixed Grid** model for desktop and a fluid single-column model for mobile. The desktop layout is centered within a 1280px container using a 12-column grid. 

- **Desktop:** 12 columns / 24px gutters / 64px side margins.
- **Tablet:** 8 columns / 20px gutters / 32px side margins.
- **Mobile:** 4 columns / 16px gutters / 16px side margins.

Horizontal rhythms should follow 8px increments. Vertical spacing between distinct sections should be generous (80px to 120px) to maintain a clean, professional "gallery" feel. Dashboard components within a section should use tight 16px or 24px padding to maintain their cohesive "card" identity.

## Elevation & Depth

Hierarchy is established primarily through **Tonal Layers** and **Low-contrast outlines**. 

Background surfaces use the neutral light gray, while "cards" or "containers" use pure white (#FFFFFF). To create separation, apply a 1px solid border (#E2E8F0). 

Shadows must be used sparingly. Use a single "Ambient Shadow" for interactive cards: `0px 4px 20px rgba(30, 41, 59, 0.05)`. On hover, the shadow should slightly deepen and the card should translate -2px on the Y-axis to provide tactile feedback without breaking the clean, flat aesthetic.

## Shapes

The shape language is **Soft** and systematic. A standard radius of 0.25rem (4px) is used for small UI components like checkboxes and input fields. Larger containers, such as portfolio cards and feature sections, use `rounded-lg` (8px) to soften the professional tone and make the interface feel modern and accessible.

Avoid fully rounded "pill" shapes except for status tags or category chips, as sharp/soft corners better reflect the "analytical" and "structured" nature of EdTech data.

## Components

- **Buttons:** Primary buttons use the Soft Cyan background with white text. They should have a flat appearance with a subtle darken-on-hover effect. Secondary buttons use a Slate Blue outline.
- **Cards:** White backgrounds, 1px Slate-200 borders, and 24px internal padding. Card headers should use `label-caps` for metadata.
- **Metrics/KPIs:** Large `metric` typography in Warm Gold, paired with a small `label-caps` description below. These should often be housed in their own micro-cards.
- **Input Fields:** 1px border (#E2E8F0), 12px vertical padding. Focus state should use a 2px Soft Cyan ring.
- **Chips/Tags:** Used for "Skills" or "Technologies." These should have a very light Slate Blue background (#F1F5F9) with Slate Blue text to keep them secondary to the main content.
- **Data Tables:** Clean, borderless rows with 1px horizontal dividers only. Use `Inter` at 14px for maximum data density.